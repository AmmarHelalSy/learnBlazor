self.assetsManifest = {
  "version": "p3KgiOrq",
  "assets": [
    {
      "hash": "sha256-/WtOLz6mtpWuJsPh4IbQeOxYeE+svASjKepRWtYkSNo=",
      "url": "MyBlazorApp.styles.css"
    },
    {
      "hash": "sha256-K3j153B4Qx57/sHT4gOICXyadidNa4qEUflLPz/OgCU=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.z6jo10m0rd.wasm"
    },
    {
      "hash": "sha256-esbkeXi/0iIJjs+MdmPU6nulNqIzqOw5a4hLgs2f6+U=",
      "url": "_framework/Microsoft.AspNetCore.Components.65wbz7t8mt.wasm"
    },
    {
      "hash": "sha256-8o1e7d2phwhchCrOcBV5r/UklI0sSixpCl8wQkEHNfE=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.ysqd97eroy.wasm"
    },
    {
      "hash": "sha256-seVr0qaYsEvzHri1us/k177XjM/aeDGtoKx6cwtF5Zo=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.bl11wz56ub.wasm"
    },
    {
      "hash": "sha256-GZWoGwG5kqPZ3m+stwPru8VvvA8V99+H3up69gTk/qU=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.fi19frkgoe.wasm"
    },
    {
      "hash": "sha256-/1hi3JsmH5xwGo03hKCGcQNWX1+X87ahYTo++7h+u3g=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.v02r25yurk.wasm"
    },
    {
      "hash": "sha256-r7YS8Hp01zUR3LoH5JsS7IrucOta+FnV199bCLii7Pk=",
      "url": "_framework/Microsoft.CSharp.j3zkownjjr.wasm"
    },
    {
      "hash": "sha256-tMRTLMK1LO5gUzD8/Xr9NEHYQTPR7MkoKs2UxTV9WPQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.8fldrj3njh.wasm"
    },
    {
      "hash": "sha256-0UQBY2SHHJBsKjGOv8NtcuuRJ6Sq06sQ0A8eV665NnQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.p623rjrpab.wasm"
    },
    {
      "hash": "sha256-y4prSY48lxC+fsh6h/ln1vT+L3j99ntadq262acdO3M=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.du3jbwjtlq.wasm"
    },
    {
      "hash": "sha256-kSMn8gMGGuTgiChs+FnxijZLvysMkGjIRfFwgUAlaI8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.7a8qwg1fzw.wasm"
    },
    {
      "hash": "sha256-nVNPInS5JfR0WDk1MK8JG6XR7EaaT+wIT7EfQWIiiLg=",
      "url": "_framework/Microsoft.Extensions.Configuration.p5dg5ykysz.wasm"
    },
    {
      "hash": "sha256-VThzM5k+QRlnvImELRVTdGXjkvTXufzMxH0GZCCwD1o=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.199illpwgv.wasm"
    },
    {
      "hash": "sha256-1nMKlEbT7mXRUMx9C6chG9R2Vs+jtdE6z86/mRrpGyI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.qgl6ezuv4d.wasm"
    },
    {
      "hash": "sha256-SBignQhR5OehDa078KhZs6MJ37jZaMAXwBOJv/+aPtc=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.gyyn78xplr.wasm"
    },
    {
      "hash": "sha256-j06UStE6FBwEz3CJbgLfbKKSePh0FaT4PK7wtDoUXs0=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.fwg0p8qiey.wasm"
    },
    {
      "hash": "sha256-BC/MCU6S9BBMqOrRwZh0plnIpsYyZKyENCmb6p3Acsk=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.wpqn02ct4s.wasm"
    },
    {
      "hash": "sha256-1jYRjcDI2/MnB5Htgj4yUaHr8gA/poI4oLgWUMZYnV0=",
      "url": "_framework/Microsoft.Extensions.Logging.2h3t8m6coa.wasm"
    },
    {
      "hash": "sha256-H+TpHvK/z4RGb8EfLe1cGb1TwnCKZAmNxt8e3s3CUSM=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.ni4towxuts.wasm"
    },
    {
      "hash": "sha256-zp3zuBmKVlE6HjY0Br1uj3fY9sU7ET4ITzgpnpmj9V0=",
      "url": "_framework/Microsoft.Extensions.Options.2nlpwp09nn.wasm"
    },
    {
      "hash": "sha256-cJ0bTIChHCfvdOf7OUoTnjDep6XHMKViMUTyqAiaD48=",
      "url": "_framework/Microsoft.Extensions.Primitives.08rjikrqbs.wasm"
    },
    {
      "hash": "sha256-oZgTa/to3sE2tSzwcZQ0GIX1meeIGAYVE7IoJDL4RkI=",
      "url": "_framework/Microsoft.JSInterop.9ydsnriizw.wasm"
    },
    {
      "hash": "sha256-Z/XKvzIKcHVmnvT7y1f4/N5zSNqzNAfjsLaBDIyCkYs=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.v6rnols3v9.wasm"
    },
    {
      "hash": "sha256-/jlp74GLHWhrCfjAmWlVClO68H3wIk+kVx9A/gjByls=",
      "url": "_framework/Microsoft.VisualBasic.Core.qljjwgjnrn.wasm"
    },
    {
      "hash": "sha256-eNtd5fm3g/oUf5hiuJ1DpH74Qzd5eTxbpPOEunY0DZQ=",
      "url": "_framework/Microsoft.VisualBasic.ocn5mkr2m2.wasm"
    },
    {
      "hash": "sha256-7cSlpviPeI+Vg0UyzN+/WIuffsrw8/mA+yvYyWejeM4=",
      "url": "_framework/Microsoft.Win32.Primitives.fhyyo0saa3.wasm"
    },
    {
      "hash": "sha256-c5UPAB7GQbMTy7sOEkPdYy4aL8tTvkFYw9ZJakHT1SM=",
      "url": "_framework/Microsoft.Win32.Registry.nbxzikm6ra.wasm"
    },
    {
      "hash": "sha256-//ejlQkIgu3InH9gIvC+Mb8QAsOIMNqA8fBIFN3oX0c=",
      "url": "_framework/MyBlazorApp.1g856mr7uv.wasm"
    },
    {
      "hash": "sha256-jUMSybpKlT9M+SSidXkB+9Ufkpm6/KB3AdkNFKSUXj8=",
      "url": "_framework/MyBlazorApp.xvpa6fsqxq.pdb"
    },
    {
      "hash": "sha256-/I6jhbBWOR/lWglc7Rxpwv34dmUTZap2GRZ8U5MUw+4=",
      "url": "_framework/System.AppContext.s2mli7k045.wasm"
    },
    {
      "hash": "sha256-TRLW74tFyYdejiCs6uJIuxPhS/Rh0NTqVByoAZ5fZTQ=",
      "url": "_framework/System.Buffers.d8ayacj23s.wasm"
    },
    {
      "hash": "sha256-eXJFjPOfQTz1QrzxB0jB5+oztcrSuo+W7zIl7oEUM6I=",
      "url": "_framework/System.Collections.Concurrent.feo024siyp.wasm"
    },
    {
      "hash": "sha256-bQcUlgX5DIF6Qdkh3Hz+sTbgMGdWPLYdy4dhUDp8xbk=",
      "url": "_framework/System.Collections.Immutable.hn2kphqqyx.wasm"
    },
    {
      "hash": "sha256-KIS6tIStO5vU3qfSwAM5/FUNiiiOPd10UgKjsTR4BEM=",
      "url": "_framework/System.Collections.NonGeneric.get8583r4q.wasm"
    },
    {
      "hash": "sha256-OhhcaU1wzF4qnEyt41wYiRkv9TrGPhK2+Fp9HBW3Kss=",
      "url": "_framework/System.Collections.Specialized.y21ri2wtjp.wasm"
    },
    {
      "hash": "sha256-avYK9JiIHAt960tqSZ6qgSA1BonSZcBQA6QGsJsolIo=",
      "url": "_framework/System.Collections.ejndmmtq8p.wasm"
    },
    {
      "hash": "sha256-GfMz8B2CdRhiHWW4+2lZBhhVOIhwP+XqE2FbtFvjWNw=",
      "url": "_framework/System.ComponentModel.9oz2etf2o8.wasm"
    },
    {
      "hash": "sha256-nXXlnLfKy/z9ZtGYq6KQquFihMIr6VhA6L/gqc9BAfI=",
      "url": "_framework/System.ComponentModel.Annotations.v1y4pnhy9x.wasm"
    },
    {
      "hash": "sha256-gNJtHXrkqglzl9wtWSYjmKsZB/dpV60tUF4XTn/lCoE=",
      "url": "_framework/System.ComponentModel.DataAnnotations.4n446zbohc.wasm"
    },
    {
      "hash": "sha256-8V3Cv7svrNJUOyC5XLddLH+Cn/Ykt1JItuoYWrT3NXQ=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.xwxd57h7as.wasm"
    },
    {
      "hash": "sha256-Wzyay5RYXulOzzOW4lRc3cfKYEDxx2kRvEsC7s04jC8=",
      "url": "_framework/System.ComponentModel.Primitives.r00dr8i32r.wasm"
    },
    {
      "hash": "sha256-KKR2VKkM2u6+glcHst5G2sOlhQKfjtl5Clut1lK0f3A=",
      "url": "_framework/System.ComponentModel.TypeConverter.41zy6wf9oa.wasm"
    },
    {
      "hash": "sha256-UMCTdZNJl+DpifSTm7JTX9MiDveaGx0YdDe26vmve1M=",
      "url": "_framework/System.Configuration.8efnux55ll.wasm"
    },
    {
      "hash": "sha256-D86swTXipVR8ybg6FaZ5abi6e25eL9G07fJtKJo0A+U=",
      "url": "_framework/System.Console.z3svuovkyl.wasm"
    },
    {
      "hash": "sha256-GnOGHVyLg+xDCUaAvFHYZzxFGRP83uFv1xvOMpIBJdA=",
      "url": "_framework/System.Core.i2gfsit2dg.wasm"
    },
    {
      "hash": "sha256-hWLdNFAs0itxe0epW/MxipXKxOxL86uUSbroosNAIXo=",
      "url": "_framework/System.Data.Common.15xzwwriko.wasm"
    },
    {
      "hash": "sha256-NTsqFBiGrsnsvNxSeHOCHtX3ir5NovlbWjPDLWAEqfs=",
      "url": "_framework/System.Data.DataSetExtensions.rwrekrq7sx.wasm"
    },
    {
      "hash": "sha256-bQe+JUXWGsr3SCnFt55wkmSf5WX0Q9UY7K4jU07ofCs=",
      "url": "_framework/System.Data.jc9hvsoz9b.wasm"
    },
    {
      "hash": "sha256-5hUC2SI169teraWv79xeyHs6BHlwtcmibtRYUQRIAxc=",
      "url": "_framework/System.Diagnostics.Contracts.m8zapvzysw.wasm"
    },
    {
      "hash": "sha256-/8cm9vLcqMIoH+jYe61m7EG6OYpmxv0+bX7tK5RdrKc=",
      "url": "_framework/System.Diagnostics.Debug.3b311sbro1.wasm"
    },
    {
      "hash": "sha256-/D7/uDNOBAyZLWrMPzw5pzHYAcHYZUjgEzXCkgHTwXg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.onf7a771xa.wasm"
    },
    {
      "hash": "sha256-y3I8QP6yhvMEaYVGjaCo3RKJ0fDOq+3L7mol9S+SNJI=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.3u9sednzu3.wasm"
    },
    {
      "hash": "sha256-nX4lOaeHse02SkrNl8GNRYrCBQBEXyrHy3KC0/sqoNw=",
      "url": "_framework/System.Diagnostics.Process.pxizkgy5ym.wasm"
    },
    {
      "hash": "sha256-SCRvFZmPh3w+A02sPn1+VGxmWNJJFYidFkMKj92zVj4=",
      "url": "_framework/System.Diagnostics.StackTrace.klgx6zaqgg.wasm"
    },
    {
      "hash": "sha256-NULze4Ko/w/GYqd6g6YdsVCwyyULl/VmSq7PNvdRxtM=",
      "url": "_framework/System.Diagnostics.TextWriterTraceListener.7lhrolq8ha.wasm"
    },
    {
      "hash": "sha256-JgRxamnubgNju9Ko7p4iEtOvZS0Cj9AWxx9XCB1neUA=",
      "url": "_framework/System.Diagnostics.Tools.i1rtuy3ws8.wasm"
    },
    {
      "hash": "sha256-5I6/dcXCd8N2bYq+TsEcLO4uG88syx0USCuYqf/8mtE=",
      "url": "_framework/System.Diagnostics.TraceSource.su9091p6cd.wasm"
    },
    {
      "hash": "sha256-98KWmM32pxDFBZeoesjCkiG3KLqT2boreDG0vqDS8Pk=",
      "url": "_framework/System.Diagnostics.Tracing.5l18zgsm1q.wasm"
    },
    {
      "hash": "sha256-x8ah4OQOIRyvRGLrUr39hfvLB0w/UVX6fcepy4Q5UhA=",
      "url": "_framework/System.Drawing.Primitives.dbya5q61h6.wasm"
    },
    {
      "hash": "sha256-g++0JBThCnodSqR84eV/iwTjp1iebfwhykE6qsaAjsU=",
      "url": "_framework/System.Drawing.nnz855j4yk.wasm"
    },
    {
      "hash": "sha256-g2fE5CDwpE4AtGRf1Jn5GSTH7Ro5TOVp7TA6QBTygKg=",
      "url": "_framework/System.Dynamic.Runtime.zk5l0u6vqy.wasm"
    },
    {
      "hash": "sha256-Z4nBv2XbdnbGQ+hQnVnFvcXeFhSAAJcMjSZMHhaDWgE=",
      "url": "_framework/System.Formats.Asn1.xadtuo15bu.wasm"
    },
    {
      "hash": "sha256-op3Pbgt05d+9ffS8w/54k6Zdn5nGwAyDHfvIjwWlNDs=",
      "url": "_framework/System.Formats.Tar.maqtwy9rpf.wasm"
    },
    {
      "hash": "sha256-rV6A6XSj+aPnevENU9F3mBTrXfYn/RgHI6xGpURDTuk=",
      "url": "_framework/System.Globalization.Calendars.nnkzew0o11.wasm"
    },
    {
      "hash": "sha256-1Xdj62ar8z+x18w5BwvJefchuoUHBLMAhdfCdfyv+BM=",
      "url": "_framework/System.Globalization.Extensions.vj2hxw2cxd.wasm"
    },
    {
      "hash": "sha256-UBCz8jn3jGY78IxIvMaFFkqV2YHGU2znyiJwdBHph7Y=",
      "url": "_framework/System.Globalization.c1ysxhlm64.wasm"
    },
    {
      "hash": "sha256-A9DFOadSNLJ9DXxQ1d2/mXj4qIfNFWWZifKU+6YOlZY=",
      "url": "_framework/System.IO.Compression.Brotli.v5j03f7yzu.wasm"
    },
    {
      "hash": "sha256-EEoh03Xy9ZNnOSBEfAhFBRhf6syWa2iSfpeoy19KsoU=",
      "url": "_framework/System.IO.Compression.FileSystem.oapcnmb898.wasm"
    },
    {
      "hash": "sha256-pTBYoX4V1Ci5dx/LYY4VkggMiQHByqxl79/tMfiT8Xw=",
      "url": "_framework/System.IO.Compression.ZipFile.n9kbwti3xz.wasm"
    },
    {
      "hash": "sha256-jdNKNdQzumTM0O5zonEHyQbOoTbSEgxacpMhExktkeo=",
      "url": "_framework/System.IO.Compression.nf0x03kqm2.wasm"
    },
    {
      "hash": "sha256-AsJzCZSPS7fAlHAT72XA8D3MbHN4bp5vHwBgGhjVNes=",
      "url": "_framework/System.IO.FileSystem.278u1momgg.wasm"
    },
    {
      "hash": "sha256-6MBZQhzHb3qZno633df0VBEB12I+qassxHKOkReDCtA=",
      "url": "_framework/System.IO.FileSystem.AccessControl.ocpn3fin63.wasm"
    },
    {
      "hash": "sha256-qRDx0fGsoO8xKl7pih9Vh722NLZYASZ6pHRtu9Qm1FM=",
      "url": "_framework/System.IO.FileSystem.DriveInfo.51cn8bey3t.wasm"
    },
    {
      "hash": "sha256-KAyO7YeYtM5XCEmO/E5Tgate5eNh8XRkFt0IzSHFG2I=",
      "url": "_framework/System.IO.FileSystem.Primitives.0ejcvk17nr.wasm"
    },
    {
      "hash": "sha256-vgcwbv+5/M9qzMnYACAvriKeBLAmoLIXsF/teJ+OVDQ=",
      "url": "_framework/System.IO.FileSystem.Watcher.ma8btvnulf.wasm"
    },
    {
      "hash": "sha256-T2K8sA1gBtvOadum4Scw+zwqqPnEmUM+c4xsZeHTVAU=",
      "url": "_framework/System.IO.IsolatedStorage.l76lfbxwit.wasm"
    },
    {
      "hash": "sha256-uZAys5x5I3g7XxzIZbdEXhpTkJSoXxmD1KA4F8bv6Z8=",
      "url": "_framework/System.IO.MemoryMappedFiles.hqsx1g6hyq.wasm"
    },
    {
      "hash": "sha256-Q8Hv4cx0IwCzRVPNPLaVRqSpgqTXwgCrr1K9BY/AfPI=",
      "url": "_framework/System.IO.Pipelines.9500alwmx9.wasm"
    },
    {
      "hash": "sha256-/Iybz6T77Tcznvz1c7MspkjJcNlWSEP+aEQVXyixE+E=",
      "url": "_framework/System.IO.Pipes.AccessControl.c8tonf5uy5.wasm"
    },
    {
      "hash": "sha256-nrjy7gjSwhMtVyHj7zHs2RBqQ7h5fwmxhtoAXXHKQ6c=",
      "url": "_framework/System.IO.Pipes.qp820k9vvz.wasm"
    },
    {
      "hash": "sha256-m4c+SCLmOi2rxzieJrcDVi2n61Gx4Hgyeo8GnQ5sJ9Q=",
      "url": "_framework/System.IO.UnmanagedMemoryStream.te9j6br1cp.wasm"
    },
    {
      "hash": "sha256-zNNJyzSS5xobmQjSvJQ2zYajATFwqTs1v8ocFSAGtlg=",
      "url": "_framework/System.IO.otuf6d74sr.wasm"
    },
    {
      "hash": "sha256-URB5MIkum09zoZL8LIHe2LH6jF4E6OnEHrcP+SZ4Hwg=",
      "url": "_framework/System.Linq.Expressions.9qursg64iq.wasm"
    },
    {
      "hash": "sha256-e7Or1axDGC0vSmHroFlaTdU/o2+q568n+M2vTWmNMss=",
      "url": "_framework/System.Linq.Parallel.f7fejzp6g2.wasm"
    },
    {
      "hash": "sha256-vFEKURslTdWYs+AvQ8+jdZfcYp2e1B+asPfpvQnkcQc=",
      "url": "_framework/System.Linq.Queryable.ksg1f547zn.wasm"
    },
    {
      "hash": "sha256-vTwCfSEU8ZbuEeaf7EDY5xxBmvXmMTtpg/7/1pgdRIw=",
      "url": "_framework/System.Linq.b6i9jn5866.wasm"
    },
    {
      "hash": "sha256-auI2+Ku6fpXBVDEvp93nHAbVA8xRZf4CJQ+0jeaYJoM=",
      "url": "_framework/System.Memory.uyrspy20w7.wasm"
    },
    {
      "hash": "sha256-2CBXOKL4E7bNIT8rKcK2YDKFcDb2OnJCedC2n02tcUY=",
      "url": "_framework/System.Net.Http.Json.osyg7lnynd.wasm"
    },
    {
      "hash": "sha256-A3yXY8sRK7yh/GXsqSFOqtARC1UI5pL4IjrPGc2I1ik=",
      "url": "_framework/System.Net.Http.t88101cxuh.wasm"
    },
    {
      "hash": "sha256-Zap2E0IOWwsX40vo5aoeEiqERvahVPdEqEhOLRha/58=",
      "url": "_framework/System.Net.HttpListener.pjiup6uulr.wasm"
    },
    {
      "hash": "sha256-ufx9prYWbkYfcqAB36G8LSdE/Jxabef0eUISFcm71M0=",
      "url": "_framework/System.Net.Mail.x2t68znxj5.wasm"
    },
    {
      "hash": "sha256-G85CSz07B5WpA1aYfeKTE+mmhSAX9U50HKF2H5hFQv0=",
      "url": "_framework/System.Net.NameResolution.darvipojrr.wasm"
    },
    {
      "hash": "sha256-TSF1TpoZBqNcqCVvHLv/NjCnjEQAOC1c6IoCeoE9tT0=",
      "url": "_framework/System.Net.NetworkInformation.dggc7r1ubt.wasm"
    },
    {
      "hash": "sha256-MINdBnqNIukeKO6dNxCn9D+s5I6UyTH+U6aZacSdBgw=",
      "url": "_framework/System.Net.Ping.s1znquqtyf.wasm"
    },
    {
      "hash": "sha256-9fQnSvxAj3o6ML4TsJP1TkW52T/CA12MLTw/eX0u+MU=",
      "url": "_framework/System.Net.Primitives.t29gzklln2.wasm"
    },
    {
      "hash": "sha256-IPEeSrm359/WHNXGfOAOvO95Tbn3nd8tUeUrxqqEGX8=",
      "url": "_framework/System.Net.Quic.sh2pare3qi.wasm"
    },
    {
      "hash": "sha256-IT5faW7bQHZCJ4HKrwK/BExKU4uABC1kT710E0MudcE=",
      "url": "_framework/System.Net.Requests.hc2hga6pkb.wasm"
    },
    {
      "hash": "sha256-deU4jhzdwvX+me7/stZRUqshePGYlGQVDWz0+Cur9Pg=",
      "url": "_framework/System.Net.Security.fr36up6qj6.wasm"
    },
    {
      "hash": "sha256-dqZI3Xy4ApVATTXSCtphwAlha2dEH8BOPv8uO/zFnTA=",
      "url": "_framework/System.Net.ServicePoint.qn67lxbu1q.wasm"
    },
    {
      "hash": "sha256-xQtdT0g7iIU9Ei024TsEiitUzwGqhCJKT+LBngmgHYg=",
      "url": "_framework/System.Net.Sockets.dijc2jj6vh.wasm"
    },
    {
      "hash": "sha256-uCKw8OsbkEM4MDVb3v13aNO9wjOu8TJjJXjDRc42REI=",
      "url": "_framework/System.Net.WebClient.80b46nh61e.wasm"
    },
    {
      "hash": "sha256-5Yu78J6pPfDSd/6o/v23hW+ZNubvqsvh5ruLaePMt5s=",
      "url": "_framework/System.Net.WebHeaderCollection.3mwc447ji4.wasm"
    },
    {
      "hash": "sha256-7UNes2b5U53/KH7OhSl/vzYGx3b3qXG+xROdb+2taMk=",
      "url": "_framework/System.Net.WebProxy.f1ecer1rjo.wasm"
    },
    {
      "hash": "sha256-VXu3EXZw6DPxx0xts6YS7NdwEsO2+cQF/36SvMzIWBY=",
      "url": "_framework/System.Net.WebSockets.3mhqx26dbt.wasm"
    },
    {
      "hash": "sha256-tkQvMdvh1bNG0tDrS9apjrSGbLfArCqQ7hZzZEQVWwA=",
      "url": "_framework/System.Net.WebSockets.Client.mo091qp4pk.wasm"
    },
    {
      "hash": "sha256-EvEGBQ5J4mf93Oo2ptKUwHiwxAdtT0VIjgT9dVgAhe0=",
      "url": "_framework/System.Net.apmwghm6mr.wasm"
    },
    {
      "hash": "sha256-+gr0le03EWaZBKckJW4qLoZ9CfQt8yxat46SV2hP9ps=",
      "url": "_framework/System.Numerics.Vectors.298h9ayyej.wasm"
    },
    {
      "hash": "sha256-hWyLH7SgVO/RrDluZ1xbViUGWf7SShAKTTZAlxZDt7s=",
      "url": "_framework/System.Numerics.b89n5cbieg.wasm"
    },
    {
      "hash": "sha256-Ks3RY0s3DLqn0BMynjFImzpPgxTZtCbfd4dQIYQHMAY=",
      "url": "_framework/System.ObjectModel.ypzsv8rp7y.wasm"
    },
    {
      "hash": "sha256-dmlLyil2xqdBc+0yMfmACcDeIGVefS4QHjRT/9mLdNs=",
      "url": "_framework/System.Private.CoreLib.uqnhzdwypx.wasm"
    },
    {
      "hash": "sha256-Rc0EMjOAGNZVMGMp7a/meo+E/WEtdkGLerrXHSIGWLg=",
      "url": "_framework/System.Private.DataContractSerialization.5st6hct31n.wasm"
    },
    {
      "hash": "sha256-X0VtWfJWrB0RiMicS+en/0REGgrfDskF0oi4rKGQCfQ=",
      "url": "_framework/System.Private.Uri.nm30bysvuf.wasm"
    },
    {
      "hash": "sha256-MB2XvqmNNjbvsbUbFNfp+GLt7XQcQ73Xrugysgtn8sA=",
      "url": "_framework/System.Private.Xml.Linq.oal8pz22v5.wasm"
    },
    {
      "hash": "sha256-r2tMto8j0V2ICD+ZfGm0QMzInrJgstrjdJxyKGD8Qmg=",
      "url": "_framework/System.Private.Xml.xkmk1pg9kr.wasm"
    },
    {
      "hash": "sha256-k2yyNHv4qCY2kRlotlDQtSIdlL0hlcrZ8gLA3A0CrWY=",
      "url": "_framework/System.Reflection.DispatchProxy.f1qnpwde5z.wasm"
    },
    {
      "hash": "sha256-9ur517/2/ohRn5ZEkSEjrp7JedCBaln0HrZ6wxjNSUc=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.yxremw531k.wasm"
    },
    {
      "hash": "sha256-Ka+EZUZgx+thLiWVrn1juZkMPjSo+nhieSBjPxSTFwE=",
      "url": "_framework/System.Reflection.Emit.Lightweight.9wuvl3yjpn.wasm"
    },
    {
      "hash": "sha256-GNB+DFaYHTqWQpuNcmS6hbLwBj9MszLwwCAy5LYoA2U=",
      "url": "_framework/System.Reflection.Emit.wqaeaqpqjx.wasm"
    },
    {
      "hash": "sha256-5VraewcNFUMrbyfvx1X2XHR8TQbtgatio49/ZHGMHa4=",
      "url": "_framework/System.Reflection.Extensions.dabnud1qlu.wasm"
    },
    {
      "hash": "sha256-9rnMU8qxblkTvEH5NmIDt6MAWULqY1heSHfs/FoeJm0=",
      "url": "_framework/System.Reflection.Metadata.mk9ue4xfjz.wasm"
    },
    {
      "hash": "sha256-TUJgiZFe7Ye01zuokcY+kCaMgcpwjW3Z6X0m/I4MvcI=",
      "url": "_framework/System.Reflection.Primitives.v1rf3dtaqo.wasm"
    },
    {
      "hash": "sha256-p2bhPIbD14QbgvSuYUKlki2jQm4iV+3dvpWHmyS+NKY=",
      "url": "_framework/System.Reflection.TypeExtensions.3pqmipm6tn.wasm"
    },
    {
      "hash": "sha256-w2TYXWd1NzN+pgAM0NQXcLUOzB47mNGOlEEGNOkE8LA=",
      "url": "_framework/System.Reflection.riqy6h8m7i.wasm"
    },
    {
      "hash": "sha256-jv+TqgolMFnQ0lpFpmfqB4G6r+kXti7IEUByJ9oP0lE=",
      "url": "_framework/System.Resources.Reader.qab1hgqeqx.wasm"
    },
    {
      "hash": "sha256-twYOOZBCcCU7QML3AQg9KPt8NvGmUBsFYlycCxAKvuQ=",
      "url": "_framework/System.Resources.ResourceManager.3hl45vgzlu.wasm"
    },
    {
      "hash": "sha256-vHIAJF1HQQTB8sCcs4PFNICdAbtPBqox4qVsPqqu3qs=",
      "url": "_framework/System.Resources.Writer.8noae5zjuo.wasm"
    },
    {
      "hash": "sha256-Bid5AWCHHiJrnEtQyRJrsTHfrKQMt8OLRY2W0xfAfIM=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.e23ug3kux4.wasm"
    },
    {
      "hash": "sha256-RPCLk90YLbUbvLYqNYiivnknzR+q6dwiWVnzkHpYuj4=",
      "url": "_framework/System.Runtime.CompilerServices.VisualC.0dbz424zo8.wasm"
    },
    {
      "hash": "sha256-5d7YNQL2N79aoduSRinKvD3HiSMKIzivlHBMBPDCKjE=",
      "url": "_framework/System.Runtime.Extensions.te5ibe9mop.wasm"
    },
    {
      "hash": "sha256-qiSGLziqGQsZy4VK8RK87yVZMZQvl+isft9RC7trrVA=",
      "url": "_framework/System.Runtime.Handles.e3jwcwvkfi.wasm"
    },
    {
      "hash": "sha256-lG0G5b5BfyTsUrwowHDjK64bktG5fmJPj5OcXCbiGpI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.4iqhe1sblh.wasm"
    },
    {
      "hash": "sha256-pBLY7JQIzExyXGEMLAWalfxAqtIWIG+LkZTFDey2eeA=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.whqysb3ecz.wasm"
    },
    {
      "hash": "sha256-BJnuxrEQnqs2JscWG+rSuLehIgNpFADcJgm0Zsxfxt0=",
      "url": "_framework/System.Runtime.InteropServices.ksoqlt99hd.wasm"
    },
    {
      "hash": "sha256-7/Dt+ZHBV/Grc41ZBOVBXJSGWUZprQ5Z5LNUhD4/9yY=",
      "url": "_framework/System.Runtime.Intrinsics.5rk8wp9xsl.wasm"
    },
    {
      "hash": "sha256-zy6j2ll8aQk0Nx0fJhnTA/Zg6MMyqOpXBqSSJld1WUg=",
      "url": "_framework/System.Runtime.Loader.ny7ii14wer.wasm"
    },
    {
      "hash": "sha256-eDOI5u8viohOny5uiq6DUf9R8fYCBj/lyzkk1x7MjcU=",
      "url": "_framework/System.Runtime.Numerics.wmwlbkynae.wasm"
    },
    {
      "hash": "sha256-wp6nRQt/GI3TIRz4TftMZ35DFfGYFPxxov6sZyt45mc=",
      "url": "_framework/System.Runtime.Serialization.6y35mmxzrq.wasm"
    },
    {
      "hash": "sha256-Pr92cIXUFQy4CIWeCj3s7vv0Umg/axv6KRfkb29rnyE=",
      "url": "_framework/System.Runtime.Serialization.Formatters.u5rt67plgv.wasm"
    },
    {
      "hash": "sha256-z8jIQBIFNhWsQcAO2L59f4I3Id2e1RtvMYrmBBgZG9A=",
      "url": "_framework/System.Runtime.Serialization.Json.57n7mkio0p.wasm"
    },
    {
      "hash": "sha256-Utlm+wnwovcUicn1MfWMLhbcCs8P2z1LbLFqSQbJh/U=",
      "url": "_framework/System.Runtime.Serialization.Primitives.ygbpnny2mc.wasm"
    },
    {
      "hash": "sha256-HqqjCv03ek6fbWsTRVgce9KpHKRPVSpT5lXjQVat+k4=",
      "url": "_framework/System.Runtime.Serialization.Xml.2widxteaf4.wasm"
    },
    {
      "hash": "sha256-Gd7O9vaVHclDJwEIAyYpW72WOFrbChLF+jJQW803vzM=",
      "url": "_framework/System.Runtime.hexcao080t.wasm"
    },
    {
      "hash": "sha256-216+tSfjiC2HCjvyTaY33dLLWNf4r/QCYGW+6biHFAI=",
      "url": "_framework/System.Security.AccessControl.15bbw5su7q.wasm"
    },
    {
      "hash": "sha256-0DBuvWiuQoLyvXUNNL227LeaLj64fDFdSU/isvyIqUY=",
      "url": "_framework/System.Security.Claims.kjb7p8c8k7.wasm"
    },
    {
      "hash": "sha256-TEqv87/aHO8l5SiD1vu8Bnt5Sg8FU3DJ2hjmWfFKMkk=",
      "url": "_framework/System.Security.Cryptography.0rw6nqo7fz.wasm"
    },
    {
      "hash": "sha256-uxypXOcE4xSlRetgLqCfpg5k21Dj2fRzLLFv93NtbHw=",
      "url": "_framework/System.Security.Cryptography.Algorithms.974cvdn89t.wasm"
    },
    {
      "hash": "sha256-dWhgNSn/0HkvJmZHZIODyRt2TrFg6s2whr0lyNRIze8=",
      "url": "_framework/System.Security.Cryptography.Cng.pvstpifg15.wasm"
    },
    {
      "hash": "sha256-sSvL24LTRfNGEAejuzPa2kDA0AJDkM9R3qa/SRqLiOE=",
      "url": "_framework/System.Security.Cryptography.Csp.9695qhf9yt.wasm"
    },
    {
      "hash": "sha256-I1RBhYNhmFZQbS/CgXtPWRgDkHcA6CPigR8GalhINhk=",
      "url": "_framework/System.Security.Cryptography.Encoding.nrsiudkmau.wasm"
    },
    {
      "hash": "sha256-R6rFjBLKGhEsMxFgDXxc8nnrYGYXOjipKFyqCLKxLds=",
      "url": "_framework/System.Security.Cryptography.OpenSsl.rvhvyfg159.wasm"
    },
    {
      "hash": "sha256-OU7d+OUcaKzB3Ka5c3yUFhL3IPYVBLQ3H5yrdpTIJrU=",
      "url": "_framework/System.Security.Cryptography.Primitives.rz8tfc0zvn.wasm"
    },
    {
      "hash": "sha256-lGiJto46vOvwdi5Gsqezea08o4AeW2FliJYxw4hra3U=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.4694slsze8.wasm"
    },
    {
      "hash": "sha256-Z9bGTVBzUSqT1Y+gGcaK5NHml0aYv+C/IdGhYwq81g8=",
      "url": "_framework/System.Security.Principal.94wgvdpj1g.wasm"
    },
    {
      "hash": "sha256-TghNxN8XXyT9WWIXWUANfkII+Ik/tzZjeNqdXEqsxYk=",
      "url": "_framework/System.Security.Principal.Windows.q6gj72jx8c.wasm"
    },
    {
      "hash": "sha256-+ax3O9/+rqTB08Yfy+Dih+FQ1Xwil4iMhyN/CE7uwAY=",
      "url": "_framework/System.Security.SecureString.z1o1nfpyhv.wasm"
    },
    {
      "hash": "sha256-Y35i5qoCuFmQ2fyZ2MCaDsEY2Kb2sPzt5d3UM/cTnnc=",
      "url": "_framework/System.Security.tg40nloc0f.wasm"
    },
    {
      "hash": "sha256-WTGKO6ipucrqepOhmsPhof3lQhQXyuAhepSNoXzg9h4=",
      "url": "_framework/System.ServiceModel.Web.jxbpi5wlg5.wasm"
    },
    {
      "hash": "sha256-UNjoTGgNCtpbvl0ft6incq3MB7gcxmxzDBuq2f7pb5o=",
      "url": "_framework/System.ServiceProcess.86z5319u6p.wasm"
    },
    {
      "hash": "sha256-2atwpo2dgsqAmmQVTq8AsuqDYsQOk70xLILPq8dxOyk=",
      "url": "_framework/System.Text.Encoding.CodePages.z9scq0q12p.wasm"
    },
    {
      "hash": "sha256-OtsfF9uFHc4Toz+ICupuIIMnsBipNj1Nyt+JRDqHwAU=",
      "url": "_framework/System.Text.Encoding.Extensions.yqrvhbgyzm.wasm"
    },
    {
      "hash": "sha256-XdKhz8cp6QZRyXg8UZiv/mcdfmDDeDrrjEUPPywScAA=",
      "url": "_framework/System.Text.Encoding.pd31zmnukr.wasm"
    },
    {
      "hash": "sha256-A15DBOljXshMaH/5pg1OjPSOP2AhBVC7Gm1LIue95/s=",
      "url": "_framework/System.Text.Encodings.Web.f1xjgsf1dl.wasm"
    },
    {
      "hash": "sha256-HpryzOMtu8dN3tmKGDI6Qgn2/R16vXiBNtbiYyS3t7U=",
      "url": "_framework/System.Text.Json.6absu9hr1f.wasm"
    },
    {
      "hash": "sha256-QHb+FxeCMFgc3QcYMjoDie7TeeN1qtueu8ZJ6/0khLQ=",
      "url": "_framework/System.Text.RegularExpressions.k7vpke4txz.wasm"
    },
    {
      "hash": "sha256-5uNPofYiMo6Fsvybdn9xpncYZtXGGdOc9MAZK2ZoW68=",
      "url": "_framework/System.Threading.Channels.mdjwqmcrfg.wasm"
    },
    {
      "hash": "sha256-9o1dqEKcerkaymttv9nnmaYtJ6T/0EEF85bhQ83fFVs=",
      "url": "_framework/System.Threading.Overlapped.68d0nhrxin.wasm"
    },
    {
      "hash": "sha256-UaV9oNK3Osb2nmk81b9/Hz+OjhFKCrjy2rKgIFSWXZ0=",
      "url": "_framework/System.Threading.Tasks.3vxtmtq8z2.wasm"
    },
    {
      "hash": "sha256-7lsw2tFBdjREWR6GzlB+zyAqXnPIE3h5OuTv2jbbkAs=",
      "url": "_framework/System.Threading.Tasks.Dataflow.ib1tcdxv3g.wasm"
    },
    {
      "hash": "sha256-VxL+yrkoY44U03HeoMUHYQOqoQyBNIEiZ+lPHgEwQ44=",
      "url": "_framework/System.Threading.Tasks.Extensions.fe58hhfni1.wasm"
    },
    {
      "hash": "sha256-iS4hh/OV/9+MtbUezobDlLCG85uESbTYt2kV4muGSng=",
      "url": "_framework/System.Threading.Tasks.Parallel.n02pnhiuoi.wasm"
    },
    {
      "hash": "sha256-XiMRppuabliDRz9bZgcGzg4BvnssK8+xw2kgYUUBCpQ=",
      "url": "_framework/System.Threading.Thread.ela0zpa4cu.wasm"
    },
    {
      "hash": "sha256-6G1zBNMKJD6pEwTpH/casLLUfLGprnW45bvXeTt0Pe8=",
      "url": "_framework/System.Threading.ThreadPool.456kqrtr37.wasm"
    },
    {
      "hash": "sha256-NEqURFacyG/0GIRYYNfxOtP4y480WslAxq8bYruhnkE=",
      "url": "_framework/System.Threading.Timer.8x28x1huyk.wasm"
    },
    {
      "hash": "sha256-WhYdkiL3qPpsBDZ40QfvhXN9xgPnhjKvm9S0ZE5CI2U=",
      "url": "_framework/System.Threading.e7dy3zxxc8.wasm"
    },
    {
      "hash": "sha256-On31WLYjoPrf/6nsyHzJKl9Wq7tpMWMkqht6dZY6PP4=",
      "url": "_framework/System.Transactions.Local.um51822t4e.wasm"
    },
    {
      "hash": "sha256-tGH9GNHgN9fzZ8J096pA7v5QiZL2vJixm+zsr60ylTI=",
      "url": "_framework/System.Transactions.grbj89ttaf.wasm"
    },
    {
      "hash": "sha256-zRNw40ZsSfnWa6rm7vMws7OjdCdjnlGkENcFFyrFrkc=",
      "url": "_framework/System.ValueTuple.ba8p6kmg8a.wasm"
    },
    {
      "hash": "sha256-0J+4ZF6llhJG5vLgkjbYv74mDvvVJGQzen7qeaRCy9o=",
      "url": "_framework/System.Web.HttpUtility.kz1rdswtnm.wasm"
    },
    {
      "hash": "sha256-rl4xSa6TYOpLgI31D8YNcxKULDJ87taQPqltjXF6M/U=",
      "url": "_framework/System.Web.ivo3eskvng.wasm"
    },
    {
      "hash": "sha256-yhDaei/WLYPm4b6n8N+p+Ljy52pNmKyutCpHaQ/8Fjs=",
      "url": "_framework/System.Windows.ipmhqe926s.wasm"
    },
    {
      "hash": "sha256-UVAEFHhgyu5szonQcT2NTdObuPPUjIWchk7ii5EaWL4=",
      "url": "_framework/System.Xml.1ortbls4va.wasm"
    },
    {
      "hash": "sha256-OFWisz47h0Ww5LEWwPE+kE+WAPF9l1dbSbi25RU0IRk=",
      "url": "_framework/System.Xml.Linq.kp3k7tm0gv.wasm"
    },
    {
      "hash": "sha256-PczobZAv4VRFTosy4OocVwpaLDTNofigcqzZ//MUOuQ=",
      "url": "_framework/System.Xml.ReaderWriter.52jfax1tqq.wasm"
    },
    {
      "hash": "sha256-quVluqY+9o+Qc2XL7OuKUKEz5guPdtRSupvcuKlBRiI=",
      "url": "_framework/System.Xml.Serialization.ue0pg3pj3d.wasm"
    },
    {
      "hash": "sha256-iUu171UBykxP8k5YGgm9iDndahEjJZMMHfVy1V6kDeI=",
      "url": "_framework/System.Xml.XDocument.1iommojzp6.wasm"
    },
    {
      "hash": "sha256-H7mENa8d7iBVbdHb/MNr1jt2njfZcDz+w16CF1XmBwg=",
      "url": "_framework/System.Xml.XPath.3bpkk2mjm4.wasm"
    },
    {
      "hash": "sha256-bLVyEPwO3VZFfE9A6cctQx9X0YlbPi4wtZG8CP83SiE=",
      "url": "_framework/System.Xml.XPath.XDocument.k25bvuxkbu.wasm"
    },
    {
      "hash": "sha256-n8cO9/kl8TgJcpCRDBZMncmWLE8BcW/jIYDmzoM3DDU=",
      "url": "_framework/System.Xml.XmlDocument.ni8e11ip1r.wasm"
    },
    {
      "hash": "sha256-IgCjgLemJBCcMw6razKvZQlSiLQGymK0+c+Y525jGPw=",
      "url": "_framework/System.Xml.XmlSerializer.me9902qi5t.wasm"
    },
    {
      "hash": "sha256-TKDL07npO9rYViOrL/X1uKIbZtgOwyfS3TlaTQ7QNEw=",
      "url": "_framework/System.ca8rpd37di.wasm"
    },
    {
      "hash": "sha256-ufB9Mo5joMyUs3DzXWWBFFIZNEVrt6h9N5stYB6Oln4=",
      "url": "_framework/WindowsBase.vy2l5u79y6.wasm"
    },
    {
      "hash": "sha256-HA1o9v6eODPO+84C33nlZvx2IoQJbkXOs6PbGrMWv/E=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-gD2XMSIt+vtDFirTg+LVASuuDVoOW3S7fY2a27Ou3Vs=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-IwCPMDwkWHz7KL51LHewflHuaaMBKJXaVNraKFCU7Fo=",
      "url": "_framework/dotnet.js.map"
    },
    {
      "hash": "sha256-RtuwNrUOdAJ5A4aS4ZmceO4ySriaYqTdC7X++6yd9lM=",
      "url": "_framework/dotnet.native.21mns4qp4i.wasm"
    },
    {
      "hash": "sha256-oS7IRiQoVt9ThQ7Y2UM3XoeY0JqPD02cg9IvRdufn2w=",
      "url": "_framework/dotnet.native.9ih887ebfz.js"
    },
    {
      "hash": "sha256-P3ZPWa6Qo/AAAW3Ig5kk9qsoQWoZhgDFHpv3IRO/lkc=",
      "url": "_framework/dotnet.runtime.js.map"
    },
    {
      "hash": "sha256-oBRKHAqZUsvCRnCzkQfB7zc45cpKLNq2NKyrG10IKx8=",
      "url": "_framework/dotnet.runtime.st3wwc8rqy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-1YSLR2eZt3ceALFV//vZUF2AloxVil3VlrW1zZYPSEI=",
      "url": "_framework/mscorlib.xd6mv31d55.wasm"
    },
    {
      "hash": "sha256-HLEwBpLfzKw2/zGSVzHzFJxznCkt/WIjahrziiMrOpA=",
      "url": "_framework/netstandard.kaml52uspo.wasm"
    },
    {
      "hash": "sha256-vGbjgqEqv4y3q5OB8W2R9LthkuF8mQfHFeNdKSReSmU=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-SfXvPVIywqEeK6+EhrK2EKo98ynPpXnEZ462S8Ggb4U=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-t8dVZ8DoFgvbPy35jvvb/Pn1H7nteF6zjfLBs3cEl7w=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-WcT/PM+gl1wzvfz1I/b4su0p3akgeG2erYBT3A5spB4=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-zZwRpwDa73mzv0voI8MgLZk/WijYNJF2alQRhoAEWEI=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-I8i6B6mJujZSNzMRy3iSYjzM19lWzW4Mf97A8VcGueg=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-dqujxK6UfpxqMowtaZBO9JOLuPSTBdYtEWDraFPfvvE=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-6vlkqIf+0a8hOGDvyatg87n62Ki0Kfu+k7a5FhJfdHU=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-Z1Z+OkzQWQyA8Qa7/s9vG5mzUb7sm295OJLNHEMhrpA=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-CiWiragqqlZnGr5cW9nJEr6NS4VVYgBe83LC28ya22E=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-kdDtxYzWsw45BGF0e12SxfwhDdjGqT5p9A/ALs/EV0g=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-YqsjFeQJr/Wb4FQGO4x/4UEfxlcNXKfbMhDRN4PNMAY=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
